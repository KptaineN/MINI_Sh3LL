/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   path_env.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eganassi <eganassi@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/30 12:47:33 by eganassi          #+#    #+#             */
/*   Updated: 2025/09/02 12:17:29 by eganassi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minish.h"

t_list	*lstnew(void *content)
{
	t_list	*new;

	new = malloc(sizeof(t_list));
	if (!new)
		perror("MALLOC in lstnew");
	new->content = content;
	new->arr_content = NULL;
	new->next = NULL;
	return (new);
}

void advance_node(t_list **node)
{
    t_list *curr;
    if (!(*node))
        return;
    curr = (*node);
 	(*node) = (*node)->next;
    free(curr);
}

//gives to the next
void	push_lst(t_list **tail, void *content)
{
	t_list *new;

	if (!*tail)
		return ;
	new = malloc(sizeof(t_list));
	if (!new)
		perror("MALLOC push_list");
	
	(*tail)->next = new;
	(*tail) = (*tail)->next; 
	new->content = content;
	new->next = NULL;
}


t_list	*set_linked_env(char **env)
{
	t_list	*head;
	t_list	*node;
    t_list	*last;
	int		i;
	i = 0;
    while (env[i])
	{
        node = lstnew(ft_strdup(env[i]));
		if (!node)
			return (NULL);
        if(i == 0)
        {    
            head = node;
            last = node;
        }
        else
        {    
            last->next = node;
            last = last->next;
        }
        last->next = NULL;
		i++;
	}
	return (head);
}

bool special_strcmp(char *dst, char *str, char c, int len)
{
	int	i;
	i = 0;
	if (dst == NULL || str == NULL || len <= 0)
		return true;
	while(i<len)
	{
		if (dst[i] != str[i])
			return true;
		i++;
	}
	if (dst[i] == c)
		return false;
	return true;
}

static char	*get_value_env(t_list *env, char *value, int len)
{
	t_list	*temp;
	temp = env;
	while (temp != NULL)
	{
		if (special_strcmp((char *)temp->content, value, '=', len) == 0)
			return (temp->content + len +1); // Skip "value="
		temp = temp->next;
	}
	return (NULL);
}

static char	*join_path(char *dir, char *cmd)
{
	char	*full_path;
	int		dir_len;
	int		cmd_len;

	dir_len = ft_strlen(dir);
	cmd_len = ft_strlen(cmd);
	full_path = malloc(dir_len + cmd_len + 2); // +2 for '/' and '\0'
	if (!full_path)
		return (NULL);
	// Copy directory
	ft_strncpy(full_path,dir,dir_len);
	full_path[dir_len++] = '/';
	ft_strncpy(&full_path[dir_len],cmd,cmd_len);
	full_path[cmd_len+dir_len] = '\0';
	return (full_path);
}

char	*find_command_path(char *cmd, t_list *env)
{
	char	*path_env;
	char	*path_copy;
	char	*dir;
	char	*full_path;

	int i, start, len;
	// If command contains '/', it's already a path
	if (ft_strchr(cmd, '/'))
	{
		if (access(cmd, F_OK | X_OK) == 0)
			return (ft_strdup(cmd));
		return (NULL);
	}
	// Get PATH envirnment variable
	path_env = get_value_env(env, "PATH", 4);
	if (!path_env)
		return (NULL);
	// Make a copy of PATH to work with
	len = ft_strlen(path_env);
	path_copy = malloc(len + 1);
	if (!path_copy)
		return (NULL);
	ft_strcpy(path_copy, path_env);
	// Search through each directory in PATH
	start = 0;
	i = 0;
	while (i <= len)
	{
		if (path_copy[i] == ':' || path_copy[i] == '\0')
		{
			path_copy[i] = '\0'; // Null-terminate current directory
			dir = path_copy + start;
			// Skip empty directories
			if (*dir != '\0')
			{
				full_path = join_path(dir, cmd);
				if (full_path && access(full_path, F_OK | X_OK) == 0)
				{
					free(path_copy);
					return (full_path);
				}
				if (full_path)
					free(full_path);
			}
			start = i + 1;
		}
		i++;
	}
	free(path_copy);
	return (NULL);
}