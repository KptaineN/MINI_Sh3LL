/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parent.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eganassi <eganassi@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 15:48:41 by eganassi          #+#    #+#             */
/*   Updated: 2025/09/02 12:17:29 by eganassi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minish.h"

void	one_parent(t_sh *sh, t_list *cmd, t_launch *all)
{
    (void)cmd;
    (void)sh;
	close(all->fd_pid[0]);
	close(all->fd_pid[1]);
}

void	start_parent(t_sh *sh, t_list *cmd, t_launch *all)
{
    (void)cmd;
    (void)sh;
	close_tri_pipes(all->fd_pid, all->curr_pipe, NULL);
	all->prev_pipe[0] = all->curr_pipe[0];
	all->prev_pipe[1] = all->curr_pipe[1];
}

void	mid_parent(t_sh *sh, t_list *cmd, t_launch *all)
{
    (void)cmd;
    (void)sh;
	close_tri_pipes(all->fd_pid, all->prev_pipe, NULL);
	all->prev_pipe[0] = all->curr_pipe[0];
	all->prev_pipe[1] = all->curr_pipe[1];
}

void	end_parent(t_sh *sh, t_list *cmd, t_launch *all)
{
    (void)cmd;
    (void)sh;
	close_tri_pipes(all->prev_pipe, all->fd_pid, NULL);
}
