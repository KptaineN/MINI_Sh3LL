/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   launch.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eganassi <eganassi@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/31 15:28:54 by eganassi          #+#    #+#             */
/*   Updated: 2025/09/02 12:17:29 by eganassi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minish.h"

static void	prep_pipes(t_sh *sh, t_launch *all)
{
	all->pid = malloc(sizeof(int) * sh->n_cmd);
	if (!all->pid)
	{
		perror("malloc for pid array");
		exit(1);
	}
	all->prev_pipe[0] = -1;
	all->prev_pipe[1] = -1;
	all->curr_pipe[0] = -1;
	all->curr_pipe[1] = -1;
}

static void	separate_family(t_family *f, t_sh *sh, t_list *cmd, t_launch *all,
		int pid)
{
	if (pid < 0)
	{
		perror("Forks");
		exit(1);
	}
	if (pid == 0)
	{
		add_pid_env(sh, all->fd_pid[0]);
		f[0](sh, cmd, all);
	}
	else
	{	
        send_pid(all->fd_pid[1], pid);
        f[1](sh, cmd, all);
    }
}

void	close_tri_pipes(int *a, int *b, int *c)
{
	close(a[0]);
	close(a[1]);
	close(b[0]);
	close(b[1]);
	if (c)
	{
		close(c[0]);
		close(c[1]);
	}
}

void	execution_button(char **cmd_line, t_sh *sh)
{
	if (cmd_line)
		execv(find_command_path(cmd_line[0], sh->env), cmd_line);
	perror("execv");
	exit(1);
}

void	launch_process(t_sh *sh, t_list **cmd)
{
	int i;
	int pid;
	t_launch all;
	i = 0;
	prep_pipes(sh, &all);
	t_family f[][2] = { {one_child, one_parent}, 
                        {start_child, start_parent},
		                {mid_child, mid_parent}, 
                        {end_child, end_parent},
                        {NULL, NULL} };

	while (*cmd != NULL && i < sh->n_cmd)
	{
		if (i < sh->n_cmd - 1 && sh->n_cmd != 1)
		{
			if (pipe(all.curr_pipe) == -1 || pipe(all.fd_pid) == -1)
			{
				perror("pipe for next command");
				break ;
			}
		}
		pid = fork();
		if (sh->n_cmd == 1) // only one
			separate_family(f[0], sh, *cmd, &all, pid);
		else if (i == 0) // first
			separate_family(f[1], sh, *cmd, &all, pid);
		else if (i == sh->n_cmd - 1) // end
			separate_family(f[3], sh, *cmd, &all, pid);
		else // middle
			separate_family(f[2], sh, *cmd, &all, pid);
        all.pid[i] = pid;
		advance_node(cmd);
		i++;
	}
	while (i--)
		waitpid(all.pid[i], NULL, 0);
	free(all.pid);
}