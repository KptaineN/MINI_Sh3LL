/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   child.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eganassi <eganassi@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 15:00:43 by eganassi          #+#    #+#             */
/*   Updated: 2025/09/02 12:17:29 by eganassi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minish.h"

void	child_signals(void)
{
	signal(SIGINT, SIG_DFL);
	signal(SIGQUIT, SIG_DFL);
}

void	one_child(t_sh *sh, t_list *cmd, t_launch *all)
{
	char	**cmd_line;
	close(all->fd_pid[1]);
	close(all->fd_pid[0]);
	cmd_line = expansion_partition_redirection(cmd, sh->env, sh->oper);
	execution_button(cmd_line, sh);
}

void	start_child(t_sh *sh, t_list *cmd, t_launch *all)
{
	char	**cmd_line;

	dup2(all->curr_pipe[1], STDOUT_FILENO);
	cmd_line = expansion_partition_redirection(cmd, sh->env, sh->oper);
	close_tri_pipes(all->fd_pid, all->curr_pipe, NULL);
	execution_button(cmd_line, sh);
}

void	mid_child(t_sh *sh, t_list *cmd, t_launch *all)
{
	char	**cmd_line;

	dup2(all->prev_pipe[0], STDIN_FILENO);
	dup2(all->curr_pipe[1], STDOUT_FILENO);
	cmd_line = expansion_partition_redirection(cmd, sh->env, sh->oper);
	close_tri_pipes(all->fd_pid, all->prev_pipe, all->curr_pipe);
	execution_button(cmd_line, sh);
}

void	end_child(t_sh *sh, t_list *cmd, t_launch *all)
{
	char	**cmd_line;

	dup2(all->prev_pipe[0], STDIN_FILENO);
	cmd_line = expansion_partition_redirection(cmd, sh->env, sh->oper);
	close_tri_pipes(all->prev_pipe, all->fd_pid, NULL);
	execution_button(cmd_line, sh);
}
