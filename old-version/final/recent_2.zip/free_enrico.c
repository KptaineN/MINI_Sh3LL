/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_enrico.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eganassi <eganassi@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 12:29:36 by eganassi          #+#    #+#             */
/*   Updated: 2025/09/01 22:34:58 by eganassi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "mini.h"

void free_string_array(char **arr)
{
    int i;

    if (!arr)
        return;
    i = 0;
    while (arr[i])
    {
        free(arr[i]);
        i++;
    }
    free(arr);
}

void free_t_arr_dic(t_arr **arr) {
    if (!arr || !*arr) return;
    for (int i = 0; i < (*arr)->len; i++) {
        t_dic *dic = (*arr)->arr[i];
        free(dic->key);
        free(dic);  // Assuming value is a function pointer, no free needed.
    }
    free((*arr)->arr);
    free(*arr);
    *arr = NULL;
}

void free_t_list(t_list **env_list) {
    t_list *curr = *env_list;
    while (curr) {
        t_list *next = curr->next;
        free(curr->content);
        free(curr);
        curr = next;
    }
    *env_list = NULL;
}

void free_shell(t_sh *sh) {
    free_t_list(&sh->env);
    free_t_arr_dic(&sh->oper);
    free_t_arr_dic(&sh->bcmd);
    free(sh);
}