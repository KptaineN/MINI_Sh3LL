/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   looping.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eganassi <eganassi@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 14:24:09 by eganassi          #+#    #+#             */
/*   Updated: 2025/09/02 10:53:33 by eganassi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "mini.h"

static void	parse_and_prepare(t_sh *sh, char *in)
{
	sh->parsed_args = custom_split(in, sh);
	display_string_array(sh->parsed_args);
	sh->cmd = build_cmd(sh, sh->parsed_args);
}

static int	process_input(t_sh *sh, char *in)
{
	if (!in || *in == '\0')
		return (0); //(cleanup_shell_iter(sh, in), 0);
	add_history(in);
	if (ft_strcmp(in, "exit") == 0)
		return (1); //(cleanup_shell_iter(sh, in), 1);
	parse_and_prepare(sh, in);

	//char * path = find_command_path(sh->cmd->arr_content[0], sh->env);
	//(void)	path;
	//free(path);
	
	launch_process(sh, &sh->cmd);
	return (free(in), 2);
}

static char	*read_user_input(void)
{
	char	*input;

	input = readline("ᕕ( ᐛ )ᕗ minishell$ ");
	if (!input)
		write(1, "exit\n", 5);
	return (input);
}

int	looping(t_sh *sh)
{
	char	*in;
	int		retour;

	retour = 0;
	while (1)
	{
		in = read_user_input();
		if (!in)
			break ;
		retour = process_input(sh, in);
		if (retour == 1)
			break ;
	}
	return (0);
}
