/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eganassi <eganassi@student.42luxembourg    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/28 07:38:32 by eganassi          #+#    #+#             */
/*   Updated: 2025/09/01 14:01:27 by eganassi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "mini.h"

int ft_echo(void *sh, int token_idx)
{
    (void) sh;
    (void) token_idx;
    return 0;
}

int ft_cd(void *sh, int token_idx)
{
    (void) sh;
    (void) token_idx;
    return 0;
}

int ft_pwd(void *sh, int token_idx)
{
    (void) sh;
    (void) token_idx;
    return 0;
}

int ft_export(void *sh, int token_idx)
{
    (void) sh;
    (void) token_idx;
    return 0;
}

int ft_unset(void *sh, int token_idx)
{
    (void) sh;
    (void) token_idx;
    return 0;
}

int ft_env(void *sh, int token_idx)
{
    (void) sh;
    (void) token_idx;
    return 0;
}

int ft_exit(void *sh, int token_idx)
{
    (void) sh;
    (void) token_idx;
    return 0;
}